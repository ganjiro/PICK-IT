********* PICK-IT! *********
Human Computer Interaction Project by Girolamo Macaluso & Marco Mistretta
Unzip the "PICK-IT!" folder wherevere you want and enjoy!
If you need a hand for the installation go watch our video tutorial: https://youtu.be/Kg2rtYsNS5E

